Write-Output 'Uninstalling Google Chrome on Windows...'
Write-Host 'Uninstalling ExamplePackage on Windows...'
# Add command to call uninstaller.  For example "msiexec /x ExamplePackage.msi /quiet"
MsiExec.exe /x googlechromestandaloneenterprise.msi /quiet