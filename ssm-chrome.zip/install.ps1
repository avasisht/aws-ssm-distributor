Write-Output 'Installing ExamplePackage on Windows...'
Write-Host 'Installing ExamplePackage on Windows...'
MsiExec.exe /i googlechromestandaloneenterprise.msi /qn